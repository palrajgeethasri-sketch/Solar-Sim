package com.becquer.solarsim;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity implements SensorEventListener {
    private WebView web;
    private SensorManager sm;
    private volatile Float lux, temp, hum, pres;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setGeolocationEnabled(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String o, GeolocationPermissions.Callback cb) { cb.invoke(o, true, false); }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public String read() {
                return "{\"lux\":" + lux + ",\"temp\":" + temp + ",\"hum\":" + hum + ",\"pres\":" + pres + "}";
            }
        }, "SolarNative");
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        int[] types = {Sensor.TYPE_LIGHT, Sensor.TYPE_AMBIENT_TEMPERATURE, Sensor.TYPE_RELATIVE_HUMIDITY, Sensor.TYPE_PRESSURE};
        for (int t : types) { Sensor s = sm.getDefaultSensor(t); if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL); }
    }
    @Override protected void onPause() { super.onPause(); sm.unregisterListener(this); }

    @Override public void onSensorChanged(SensorEvent e) {
        float v = e.values[0];
        switch (e.sensor.getType()) {
            case Sensor.TYPE_LIGHT: lux = v; break;
            case Sensor.TYPE_AMBIENT_TEMPERATURE: temp = v; break;
            case Sensor.TYPE_RELATIVE_HUMIDITY: hum = v; break;
            case Sensor.TYPE_PRESSURE: pres = v; break;
        }
    }
    @Override public void onAccuracyChanged(Sensor s, int a) {}
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
