Solar Weather Sim - Android project (WebView + native sensors)
Option A: Android Studio -> Open this folder -> Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
Option B (no Android Studio): push this folder to a GitHub repo -> Actions tab -> "Build APK" -> download artifact SolarSim-debug-apk.
Requires JDK 17, Gradle 8.7+ (Android Studio fetches it automatically).
